#include <stdlib.h>
#include <time.h>

char randchar() {
    return 'A' + rand() % 26;
}
